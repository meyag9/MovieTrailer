import fresh_tomatoes
import media
# these imports connect the files so they can work together to create the web page


toy_story = media.Movie("Toy Story", "This movie is about a boy named Andy",
                        "http://www.impawards.com/1995/posters/toy_story_ver1_xlg.jpg",
                        "https://youtu.be/KYz2wyBy3kc")

forrest_gump = media.Movie("Forrest Gump", "Mamma says life is like a box of chocolates","http://www.impawards.com/1994/posters/forrest_gump.jpg",
                           "https://youtu.be/uPIEn0M8su0")

ET = media.Movie("E.T.", "This movie is about a boy who becomes friends with an alien", "http://images.moviepostershop.com/et--the-extra-terrestrial-movie-poster-1982-1010725704.jpg", "https://youtu.be/_7-2PB4jj2o")

kingKong = media.Movie("King Kong","Woman falls in love with King Kong", "http://www.serkis.com/images/king-kong-poster.jpg", "https://youtu.be/e20Em3A4Nb0")

walkTheLine = media.Movie("Walk the Line", "Johnny cash and June Carter", "http://www.freemovieposters.net/posters/walk_the_line_2005_1794_medium.jpg","https://youtu.be/8BzLc2hQJF0")

harry = media.Movie("Harry Potter", "Harry learns he is a wizard", "http://www.gstatic.com/tv/thumb/movieposters/28630/p28630_p_v8_at.jpg", "https://youtu.be/PbdM1db3JbY")


movies = [toy_story, forrest_gump, ET, kingKong, walkTheLine, harry]
fresh_tomatoes.open_movies_page(movies) #passing array of objects to display on the webpage



