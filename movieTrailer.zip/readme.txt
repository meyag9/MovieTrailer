Udacity Full Stack Developer Nano Degree
Movie Trailer Project

To run the program:
1. Unzip the movieiTrailer.zip file. 
2. open the file "entertainmentCenter.py" with python IDE
3. Run Module

Steps in making this program: 
1. Created a file "media.py" and created a class "Movie" that would initialize movie title, 
summary, poster, and trailer in the init function. 
2. Created another file "entertainmentCenter.py" and imported media. In this file I 
created 6 instances of the movie class and initialized them with specific data. Next I 
created a array of instances so that the information can be displayed on the web page. 
3. I downloaded the file "fresh_tomatoes.py" from the Udacity course and passed my movie 
array to the "open_movies_page" function. 
4. Test/run the module from "media.py"

Copyright (c) 2016 Meya Gorbea

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

